from mongoengine import *
import datetime

class Diary(Document):
    diary_name = StringField(max_length=200, required=False)
    user_id = StringField(max_length=200, required=False)
    diary_content = DictField(default={})
    created_date = DateTimeField(default=datetime.datetime.now)

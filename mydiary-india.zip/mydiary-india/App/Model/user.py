from mongoengine import *
import datetime

class User(Document):
    username = StringField(max_length=200, required=False)
    role = BooleanField(required=False, default=False)
    profileimage = StringField( required=False)
    email = EmailField(max_length=200, required=False)
    password = StringField(max_length=200, required=False)
    auth_token = StringField(max_length=500, required=False)
    login_time = DateTimeField(default=datetime.datetime.now)
    status = BooleanField(required=False)
    otp = StringField(max_length=8, required=False)

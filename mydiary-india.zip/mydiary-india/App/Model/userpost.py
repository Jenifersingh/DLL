from mongoengine import *
import datetime

class Userpost(Document):
    userid = StringField(max_length=200, required=False)
    username = StringField(max_length=200, required=False)
    email = EmailField(max_length=200, required=False)
    subject = StringField(max_length=200, required=False)
    message = StringField(required=False)
    postdate = StringField(required=False)
    

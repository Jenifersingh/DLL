import jwt
import datetime
import json
import math, random 
import smtplib
from email.message import EmailMessage
from flask import Blueprint, request, jsonify
from .Model.user import User
from cryptography.fernet import Fernet

auth = Blueprint('auth', __name__, url_prefix="/api/v1/mydiary")

token = {}
token['SECRET_KEY'] = 'apitokengeneration'
gmail_user = 'mydiary.notification@gmail.com'
gmail_password = 'Mydiary@2020'
urlhost = "https://mydiary-diary.herokuapp.com/"

def generate_key():
    """
    Generates a key and save it into a file
    """
    key = Fernet.generate_key()
    with open("secret.key", "wb") as key_file:
        key_file.write(key)

def load_key():
    """
    Load the previously generated key
    """
    return open("secret.key", "rb").read()

def encrypt_message(message):
    """
    Encrypts a message
    """
    key = load_key()
    encoded_message = message.encode()
    f = Fernet(key)
    encrypted_message = f.encrypt(encoded_message)

    return encrypted_message

def decrypt_message(encrypted_message):
    """
    Decrypts an encrypted message
    """
    key = load_key()
    f = Fernet(key)
    decrypted_message = f.decrypt(bytes(encrypted_message, 'utf-8'))
    return decrypted_message.decode()

def validate_session(id):
    try:
        auth_token = request.headers['Authorization']
        session = User.objects(id = id, auth_token = auth_token, role = False).first()
        if session:
            return True
        else:
            return False
    except:
        return False

def generateOTP(): 
    try:
        # Declare a digits variable   
        # which stores all digits  
        digits = "0123456789"
        OTP = "" 
    
        # length of password can be chaged 
        # by changing value in range 
        for i in range(6) : 
            OTP += digits[math.floor(random.random() * 10)] 
    
        return OTP 
    except:
        return 999999

def send_email(to, otp, subject):
    try:
        msg = EmailMessage()
        if 'verification' in subject.lower():
            process = 'verify Account'
            url = urlhost + "verifyaccount?email={email}&otp={otp}".format(email=to, otp=otp)
        else:
            url = urlhost + "changepassword?email={email}&otp={otp}".format(email=to, otp=otp)
            process = 'proceed your request'
        email_temp = open("email_template.txt", 'r')
        email_content = email_temp.read()
        email_content = email_content.format(user = to.split('@')[0], otp = otp, req = subject, process = process, url = url)
        email_temp.close()
        msg.set_content(email_content)
        msg['Subject'] = subject
        msg['From'] = "My Diary"
        msg['To'] = to

        try:
            # Send the message via our own SMTP server.
            server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
            server.login(gmail_user, gmail_password)
            server.send_message(msg)
            server.quit()
            return True
        except:
            return False
    except:
        return False

#Login API
@auth.route('/login', methods = ['POST'])
def login():
    try:
        try:
            email = request.json['email']
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Email is required'})
        try:
            password = request.json['password']
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Password is required'})
        user = User.objects(email = email).first()
        if user:
            if decrypt_message(user.password) == password:
                if user.status:
                    auth_token = str(jwt.encode(
                            {'email': email, 'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=30)},
                            token['SECRET_KEY']).decode('UTF-8'))
                    user.update(auth_token = auth_token, otp = "mydiary")
                    return jsonify({'id' : str(user.id), 'email' : user.email ,'username' : user.username, 'auth_token' : auth_token, 
                                'Status' : 'True', 'Message' : 'Logged successfully', 'profileimage': user.profileimage})
                else:
                    otp = generateOTP()
                    user.update(otp = otp)
                    email_status = send_email(email, otp, 'MyDiary - Account Verification')
                    return jsonify({'Status' : 'False', 'Message' : 'Please verify the account to continue, OTP has been sent to email', 'id' : str(user.id)})
            else:
                return jsonify({'Status' : 'False', 'Message' : 'Username or Password invalid'})
        else:
            return jsonify({'Status' : 'False', 'Message' : 'User not exists please, register and try login again'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})

#SignUp API
@auth.route('/signup', methods = ['POST'])
def signup():
    try:
        try:
            username = request.json['username']
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Username is required'})
        try:
            email = request.json['email']
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Email is required'})
        try:
            password = request.json['password']
            re_password = request.json['repassword']
            if password != re_password:
                return jsonify({'Status' : 'False', 'Message' : 'Password and Confirm Password is not matching'})
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Password or Confirm Password is required'})
        check_user = User.objects(email = email).first()
        if check_user:
            if check_user.status:
                return jsonify({'Status' : 'False', 'Message' : 'Username already exist, Please Login to continue'})
            else:
                otp = generateOTP()
                check_user.update(otp = otp)
                email_status = send_email(username, otp, 'MyDiary - Account Verification')
                return jsonify({'Status' : 'False', 'Message' : 'Username already exist, Please verify the account OTP has been sent to email', 'id' : str(check_user.id)})
        try:
            otp = generateOTP()
            email_status = send_email(email, otp, 'MyDiary - Account Verification')
            user = User(username = username, email = email, password = str(encrypt_message(password).decode()), status = False, otp = otp, profileimage='').save()
            return jsonify({'Status' : 'True', 'Message' : 'Registered successfully, Please login to continue',
                    'username' : user.username, 'email' : user.email, 'id' : str(user.id)})
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Failed to register new user, Please try again after sometime'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})

#Verification API
@auth.route('/<string:email>/verifyuser', methods = ['PUT'])
def verifyuser(email):
    try:
        try:
            otp = request.json['otp']
            if otp == "mydiary":
                return jsonify({'Status' : 'False', 'Message' : 'OTP is required'})
        except:
            return jsonify({'Status' : 'False', 'Message' : 'OTP is required'})
        user = User.objects(email = email, otp = str(otp)).first()
        if user:
            user.update(status = True)
            return jsonify({'Status' : 'True', 'Message' : 'User Verified successfully, Please login to continue..'})
        else:
            return jsonify({'Status' : 'False', 'Message' : 'Incorrect OTP!, Please try again'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})


#Send OTP API
@auth.route('/sendotp', methods = ['PUT'])
def sendotp():
    try:
        try:
            email = request.json['email']
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Email is required'})
        user = User.objects(email = email).first()
        if user:
            otp = generateOTP()
            email_status = send_email(email, otp, 'MyDiary - Password Change')
            user.update(otp = otp)
            return jsonify({'Status' : 'True', 'Message' : 'OTP has been sent successfully to registered email'})
        return jsonify({'Status' : 'False', 'Message' : 'User does not exist'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})


#Change Password API
@auth.route('/changepassword', methods = ['PUT'])
def changepassword():
    try:
        try:
            otp = request.json['otp']
        except:
            return jsonify({'Status' : 'False', 'Message' : 'OTP is required'})
        try:
            email = request.json['email']
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Email is required'})
        try:
            password = request.json['password']
            re_password = request.json['repassword']
            if password != re_password:
                return jsonify({'Status' : 'False', 'Message' : 'Password and Retype Password is not matching'})
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Password or Retype Password is required'})
        user = User.objects(email = email, otp = str(otp)).first()
        if user:
            user.update(password = str(encrypt_message(password).decode()))
            return jsonify({'Status' : 'True', 'Message' : 'Password Changed successfully'})
        return jsonify({'Status' : 'False', 'Message' : 'Incorrrect OTP'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})

#Change Password API
@auth.route('/profilechangepassword', methods = ['PUT'])
def profilechangepassword():
    try:
        try:
            currentpassword = request.json['currentpassword']
        except:
            return jsonify({'Status' : 'False', 'Message' : 'currentpassword is required'})
        try:
            email = request.json['email']
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Email is required'})
        try:
            password = request.json['password']
            re_password = request.json['repassword']
            if password != re_password:
                return jsonify({'Status' : 'False', 'Message' : 'Password and Retype Password is not matching'})
        except:
            return jsonify({'Status' : 'False', 'Message' : 'Password or Retype Password is required'})
        user = User.objects(email = email).first()
        if user:
            if decrypt_message(user.password) == currentpassword:
                user.update(password = str(encrypt_message(password).decode()))
                return jsonify({'Status' : 'True', 'Message' : 'Password Changed successfully'})
            else:
                return jsonify({'Status' : 'False', 'Message' : 'Incorrect current password'})
        else:
            return jsonify({'Status' : 'False', 'Message' : 'User not exist please, register or login and try again'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})

#Logout API
@auth.route('/logout', methods = ['PUT'])
def logout():
    try:
        try:
            id = request.json['id']
        except:
            return jsonify({'Status' : 'True', 'Message' : 'Logged out successfully'})
        user = User.objects(id = id).first()
        if user:
            user.update(auth_token = '')
        return jsonify({'Status' : 'True', 'Message' : 'Logged out successfully'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})

#upload Image API
@auth.route('/<string:id>/uploadimage', methods = ['PUT'])
def upload_image(id):
    try:
        if validate_session(id):
            try:
                profileimage = request.json['profileimage']
            except:
                return jsonify({'Status' : 'False', 'Message' : 'profileimage is required'})
            user = User.objects(id = id).first()
            if user:
                user.update(profileimage = profileimage)
            return jsonify({'Status' : 'True', 'Message' : 'profileimage updated successfully', 'profileimage': user.profileimage})
        return jsonify({'Status' : 'False', 'Message' : 'Failed to upload image, Session Expired'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})

from cryptography.fernet import Fernet

def generate_key():
    """
    Generates a key and save it into a file
    """
    key = Fernet.generate_key()
    with open("secret.key", "wb") as key_file:
        key_file.write(key)
        print(key)

def load_key():
    """
    Load the previously generated key
    """
    return open("secret.key", "rb").read()

def encrypt_message(message):
    """
    Encrypts a message
    """
    key = load_key()
    encoded_message = message.encode()
    f = Fernet(key)
    encrypted_message = f.encrypt(encoded_message)

    print(encrypted_message)
    return encrypted_message

def decrypt_message(encrypted_message):
    """
    Decrypts an encrypted message
    """
    key = load_key()
    f = Fernet(key)
    decrypted_message = f.decrypt(bytes(encrypted_message, 'utf-8'))

    print(decrypted_message.decode())
    return decrypted_message.decode()

#if __name__ == "__main__":
    #generate_key()
    #encrypt = encrypt_message("encrypt this message")
    #print(type(encrypt))
    #decrypt_message(bytes("gAAAAABf6HLQY9S4denFx1ryIZZOb6hHahxBK_31SCN-vV5yiwjAtYchaCHv8JTdPTi3Ciy26fPTtDxFhBv-hHZlCfT2hCFH3bajbCp4bKcRhFPF_eJ7afo=", 'utf-8'))

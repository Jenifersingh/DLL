import jwt
import datetime
import json
from flask import Blueprint, request, jsonify
from .Model.diary import Diary
from .Model.user import User

diary = Blueprint('diary', __name__, url_prefix="/api/v1/mydiary")

def validate_session(id):
    try:
        auth_token = request.headers['Authorization']
        session = User.objects(id = id, auth_token = auth_token).first()
        if session:
            return True
        else:
            return False
    except:
        return False

@diary.route('/<string:id>/getalldiary', methods = ['GET'])
def get_all_diary(id):
    try:
        if validate_session(id):
            check_status = False
            try:
                checkdiary = Diary.objects(user_id = id)
                userdiarylist = []
                for _checkdiary in checkdiary:
                    userdiarylist.append({'diaryid' : str(_checkdiary.id), 
                    'diaryname' : _checkdiary.diary_name, 'diarycontent' : _checkdiary.diary_content})
                return jsonify({'Status' : 'True', 'Message' : 'User Diary', 'userdiarylist' : userdiarylist})
            except:
                return jsonify({'Status' : 'False', 'Message' : 'Failed to Get Diary'})
        return jsonify({'Status' : 'False', 'Message' : 'Failed to Get Diary, Session Expired'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})

@diary.route('/<string:id>/adddiary', methods = ['POST'])
def add_diary(id):
    try:
        if validate_session(id):
            check_status = False
            try:
                try:
                    diary_name = request.json['diary_name']
                except:
                    x = datetime.datetime.now()
                    diaryname_date = x.strftime("%x").replace('/', '')
                    diaryname_time = x.strftime("%X").replace(':', '')
                    diary_name = 'Diary ' + diaryname_time
                try:
                    checkdiary = Diary.objects(user_id = id)
                    userdiarylist = []
                    for _checkdiary in checkdiary:
                        userdiarylist.append({'diaryid' : str(_checkdiary.id), 
                        'diaryname' : _checkdiary.diary_name, 'diarycontent' : _checkdiary.diary_content})
                        if _checkdiary.diary_name == diary_name:
                            check_status = True
                    
                    if check_status:
                        return jsonify({'Status' : 'False', 'Message' : 'Failed to Add Diary, Diary name {0} already exist'.format(diary_name)})
                except:
                    return jsonify({'Status' : 'False', 'Message' : 'Failed to Add Diary, Please try again'})
                if len(checkdiary) < 4:
                    diary = Diary(user_id = id, diary_name = diary_name).save()
                    userdiarylist.append({'diaryid' : str(diary.id), 
                            'diaryname' : diary.diary_name, 'diarycontent' : diary.diary_content})
                    return jsonify({'Status' : 'True', 'Message' : 'Diary Added successfully',
                    'diary_id' : str(diary.id), 'diary_name' : diary.diary_name, 'userdiarylist' : userdiarylist})
                else:
                    return jsonify({'Status' : 'False', 'Message' : 'Failed to Add Diary, We allowed only 4 diary per user, Please delete old diary to add new one..'})
            except:
                return jsonify({'Status' : 'False', 'Message' : 'Failed to Add Diary'})
        return jsonify({'Status' : 'False', 'Message' : 'Failed to Add Diary, Session Expired'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})


@diary.route('/<string:id>/updatemydiary/<string:diaryid>', methods = ['PUT'])
def updatemydiary(id, diaryid):
    try:
        if validate_session(id):
            try:
                diary_name = request.json['diaryname']
                if len(diary_name) > 20:
                    return jsonify({'Status' : 'False', 'Message' : 'Failed to Update Diary Name, {0} Maximum 20 characters allowed'.format(year)})
                try:
                    checkdiary = Diary.objects(user_id = id, diary_name = diary_name).first()
                    if checkdiary:
                        return jsonify({'Status' : 'False', 'Message' : 'Failed to Update Diary Name, {0} already exist'.format(year)})
                    diary = Diary.objects(id = diaryid).first()
                    diary.update(diary_name = diary_name)
                    return jsonify({'Status' : 'True', 'Message' : 'Diary name updated successfully'})
                except:
                    return jsonify({'Status' : 'False', 'Message' : 'Failed to Update Diary Name, Please try again'})
            except:
                return jsonify({'Status' : 'False', 'Message' : 'Failed to Update Diary Name'})
        else:
            return jsonify({'Status' : 'False', 'Message' : 'Failed to Update Diary Name, Session Expired'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})


@diary.route('/<string:id>/updatepage/<string:diaryid>', methods = ['PUT'])
def updatepage(id, diaryid):
    try:
        if validate_session(id):
            try:
                try:
                    page_no = request.json['pageno']
                except:
                    return jsonify({'Status' : 'False', 'Message' : 'Page no is required'})
                try:
                    page_content = request.json['pagecontent']
                except:
                    return jsonify({'Status' : 'False', 'Message' : 'Page Content is required'})
                try:
                    diary = Diary.objects(id = diaryid, user_id = id).first()
                    diary_content = diary.diary_content
                    diary_content[page_no] = page_content
                    if diary:
                        diary.update(diary_content = diary_content)
                        return jsonify({'Status' : 'True', 'Message' : 'Page Updated successfully'})
                    return jsonify({'Status' : 'False', 'Message' : 'Failed to update page, Diary doesnt exist'})
                except:
                    return jsonify({'Status' : 'False', 'Message' : 'Failed to Update Page Content, Please try again'})
            except:
                return jsonify({'Status' : 'False', 'Message' : 'Failed to Update Page Content'})
        return jsonify({'Status' : 'False', 'Message' : 'Failed to Update Page Content, Session Expired'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})



@diary.route('/<string:id>/deletediary/<string:diaryid>', methods = ['DELETE'])
def delete_diary(id, diaryid):
    try:
        if validate_session(id):
            try:
                try:
                    deletediary = Diary.objects(user_id = id, id = diaryid)
                    if deletediary:
                        deletediary.delete()
                        return jsonify({'Status' : 'True', 'Message' : 'Diary deleted susscessfully'})
                    return jsonify({'Status' : 'False', 'Message' : 'Failed to Delete Diary, Diary not exist'})
                except:
                    return jsonify({'Status' : 'False', 'Message' : 'Failed to Delete Diary, Please try again'})
            except:
                return jsonify({'Status' : 'False', 'Message' : 'Failed to Delete Diary'})
        return jsonify({'Status' : 'False', 'Message' : 'Failed to Delete Diary, Session Expired'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})
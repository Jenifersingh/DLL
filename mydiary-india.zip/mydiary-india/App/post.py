import datetime
import smtplib
from flask import Blueprint, request, jsonify
from .Model.userpost import Userpost
from .Model.user import User

post = Blueprint('post', __name__, url_prefix="/api/v1/mydiary")

def validate_session(id):
    try:
        auth_token = request.headers['Authorization']
        session = User.objects(id = id, auth_token = auth_token).first()
        if session:
            return True
        else:
            return False
    except:
        return False

#Post API
@post.route('/<string:id>/post', methods = ['POST'])
def user_post(id):
    try:
        if validate_session(id):
            try:
                username = request.json['username']
            except:
                return jsonify({'Status' : 'False', 'Message' : 'Name is required'})
            try:
                email = request.json['email']
            except:
                return jsonify({'Status' : 'False', 'Message' : 'Email is required'})
            try:
                subject = request.json['subject']
            except:
                return jsonify({'Status' : 'False', 'Message' : 'Subject is required'})
            try:
                message = request.json['message']
            except:
                return jsonify({'Status' : 'False', 'Message' : 'Message is required'})
            x = datetime.datetime.now()
            date = x.strftime("%x")
            time = x.strftime("%X")
            postdate = date + " " + time
            userposts = Userpost(email = email, subject = subject, message = message, userid  = id, 
            username = username, postdate = postdate).save()
            if userposts:
                userpostslist = []
                userposts = Userpost.objects()
                for _userposts in userposts:
                    userpostslist.append({'username' : _userposts.username, 'message': _userposts.message, 'userid': _userposts.userid,
                    'email' : _userposts.email, 'subject' : _userposts.subject, 'postid': str(_userposts.id), 'postdate': _userposts.postdate})
                return jsonify({'Status' : 'True', 'Message' : 'Your post has been logged successfully!', 'userpostlist': userpostslist})
            else:
                json_data = {'Status' : 'False', 'Message' : 'Failed to post your comment, Please try again!'}
                return jsonify(json_data)
        return jsonify({'Status' : 'False', 'Message' : 'Failed to Get Diary, Session Expired'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})


#Post API
@post.route('/<string:id>/deletepost/<string:postid>', methods = ['DELETE'])
def delete_post(id, postid):
    try:
        if validate_session(id):
            userposts = Userpost(userid = id, id = postid)
            if userposts:
                userposts.delete()
                userpostslist = []
                userposts = Userpost.objects()
                for _userposts in userposts:
                    userpostslist.append({'username' : _userposts.username, 'message': _userposts.message, 'userid': _userposts.userid,
                    'email' : _userposts.email, 'subject' : _userposts.subject, 'postid': str(_userposts.id), 'postdate': _userposts.postdate})
                return jsonify({'Status' : 'True', 'Message' : 'Your post has been deleted successfully!', 'userpostlist': userpostslist})
            else:
                json_data = {'Status' : 'False', 'Message' : 'Failed to post your comment, Please try again!'}
                return jsonify(json_data)
        return jsonify({'Status' : 'False', 'Message' : 'Failed to Get Diary, Session Expired'})
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})

@post.route('/getallpost', methods = ['GET'])
def getalluser_post():
    try:
        userpostslist = []
        userposts = Userpost.objects()
        for _userposts in userposts:
            userpostslist.append({'username' : _userposts.username, 'message': _userposts.message, 'userid': _userposts.userid,
             'email' : _userposts.email, 'subject' : _userposts.subject, 'postid': str(_userposts.id), 'postdate': _userposts.postdate})
        if userposts:
            return jsonify({'Status' : 'True', 'Message' : 'All user posts', 'userpostlist': userpostslist})
        else:
            json_data = {'Status' : 'False', 'Message' : 'Failed to post your comment, Please try again!'}
            return jsonify(json_data)
    except:
        return jsonify({'Status' : 'False', 'Message' : 'Fatal error, Please contact Administrator'})
from flask import Flask
from App.auth import auth
from App.mydiary import diary
from App.post import post
from flask_mongoengine import MongoEngine
from flask_cors import CORS
import pymongo

app = Flask(__name__)
CORS(app)

app.register_blueprint(auth)
app.register_blueprint(diary)
app.register_blueprint(post)

@app.route('/')
def temp():
    return "<h1>HELLO</h1>"

app.config['MONGODB_SETTINGS'] = {
    "db": "MyDiary",
    'host': 'mongodb+srv://MyDairyAPI:MyDiary2020API@mydiary.apa84.mongodb.net/MyDiary?authSource=admin&replicaSet=atlas-qsfa27-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true',
    'port': 27017,
}

db = MongoEngine(app)

if __name__ == '__main__':
    app.run()

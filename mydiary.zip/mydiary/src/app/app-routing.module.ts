import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DiaryComponent } from './diary/diary.component';
import { DiaryHomeComponent } from './diary-home/diary-home.component';
import { LogoutComponent } from './logout/logout.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'login', component: HomeComponent },
  { path: 'register', component: HomeComponent },
  { path: 'myprofile', component: HomeComponent },
  { path: 'forgot-password', component: HomeComponent },
  { path: 'posts', component: HomeComponent },
  { path: 'changepassword', component: HomeComponent },  
  { path: 'verifyaccount', component: HomeComponent },
  { path: 'my-diary', component: DiaryHomeComponent },
  { path: 'login/authorization', component: DiaryHomeComponent },
  { path: 'view-my-diary', component: DiaryComponent },
  { path: 'logout', component: LogoutComponent },
  { path: '**', component: HomeComponent }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }

import { BrowserModule } from '@angular/platform-browser';
import { NgModule, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms'; // <-- NgModel lives here
import { HttpClientModule } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { DiaryComponent } from './diary/diary.component';
import { DatepickerComponent } from './datepicker/datepicker.component';
import { LoadingComponent } from './loading/loading.component';
import { DiaryHomeComponent } from './diary-home/diary-home.component';
import { DiaryFrontPageComponent } from './diary-front-page/diary-front-page.component';
import { LogoutComponent } from './logout/logout.component';
import { HomeComponent } from './home/home.component';
import { MydiaryapicallService } from './mydiaryapicall.service';

@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    DiaryComponent,
    DatepickerComponent,
    LoadingComponent,
    DiaryHomeComponent,
    DiaryFrontPageComponent,
    LogoutComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [ CookieService ],
  bootstrap: [AppComponent]
})
export class AppModule implements OnInit{
  apicall;
  data;

  constructor(apicall : MydiaryapicallService){
    
  }
  ngOnInit(){
    
  }
}

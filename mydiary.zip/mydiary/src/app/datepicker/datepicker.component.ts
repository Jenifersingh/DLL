import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.css']
})
export class DatepickerComponent implements OnInit {

  constructor() {
    this.showCalendar(this.currentMonth, this.currentYear);
   }

  ngOnInit(): void {
    
  }

  datelist; monthHeader; yearHeader; monthselected; 
  @Output() userdate = new EventEmitter<any>(); 
  monthlist; days; yearlist; mydate; 
  
  monthsArr = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  daysArr = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  today = new Date();
  currentMonth = this.today.getMonth();
  currentYear = this.today.getFullYear();
  dateselected = this.today.getDate();
  dateHeader = this.today.getDate();
  selectedyear = this.currentYear;
  selectedmonth = this.currentMonth;
  @Input() userdata;
  

  showCalendar(month, year) {
    this.monthlist = [];
    this.yearlist = [];
    var datelist = [];
    var firstDay = new Date(year, month).getDay();
    var monthString = this.monthsArr[month];
    this.monthselected = monthString;
    var monthHeader = monthString.substring(0, 3);
    var yearHeader = year;
    var date = 1;

    for (var i = 0; i < 6; i++) {
      var daterow = [];

      for (var j = 0; j < 7; j++) {
        var test = ""
        if (i === 0 && j < firstDay) {
          daterow.push("")
        } else if (date > this.daysInMonth(month, year)) {
          break;
        } else {
          daterow.push(date.toString())
          if (date === this.today.getDate() && year === this.today.getFullYear() && month === this.today.getMonth()) {

          }
          date++;
        }
      }
      datelist.push(daterow)

    }
    
    this.datelist = datelist;
    this.monthHeader = monthHeader;
    this.yearHeader = yearHeader;
    this.days = this.daysArr;
    var userdata = { 'date': this.dateHeader, 'month': this.monthHeader, 'year': this.yearHeader, 'dateselected': this.dateselected, 'datelist': this.datelist};
    userdata['editmode'] = this.userdata ? this.userdata['editmode'] : false;
    this.userdata = userdata;
    this.userdate.emit(userdata);
    this.datelist = userdata.datelist;
  }
  
  daysInMonth(month, year) {
    return 32 - new Date(year, month, 32).getDate();
  }

  previous() {
    if (!this.userdata['editmode']) {
      this.selectedyear = this.selectedmonth === 0 ? this.selectedyear - 1 : this.currentYear;
      this.selectedmonth = this.selectedmonth === 0 ? 11 : this.selectedmonth - 1;
      this.showCalendar(this.selectedmonth, this.selectedyear);
    }
  }

  next() {
    if (!this.userdata['editmode']) {
      this.selectedyear = this.selectedmonth === 11 ? this.selectedyear + 1 : this.selectedyear;
      this.selectedmonth = (this.selectedmonth + 1) % 12;
      this.showCalendar(this.selectedmonth, this.selectedyear);
    }
  }

  selectdate(date){
    if (typeof (date) == "undefined" || date == "undefined" || this.userdata['editmode']){
      this.dateselected = this.dateselected;
    }
    else{
      this.dateselected = date;
    }
    this.dateHeader = this.dateselected;
    this.mydate = this.dateselected + "-" + this.monthHeader + "-" + this.yearHeader
    var userdata = { 'date': this.dateHeader, 'month': this.monthHeader, 'year': this.yearHeader, 'dateselected': this.dateselected, 'datelist': this.datelist, 'editmode' : this.userdata['editmode']};
    this.userdata = userdata;
    this.userdate.emit(this.userdata);
    this.datelist = userdata.datelist;
  }

  selectyear(){
    this.datelist = [];
    this.days = [];
    this.monthlist = [];
    var yeardata = [];
    if (this.yearlist.length === 0){
      var j = 0;
      var years = [];
      for (var i = 2000; i <= this.today.getFullYear(); i++) {
        j++;
        years.push(i);
        if (j === 4){
          yeardata.push(years);
          years = [];
          j = 0;
        }
      }
      if (j < 4) {
        yeardata.push(years);
        years = [];
        j = 0;
      }
      this.yearlist = yeardata;
    }
    else{
      this.showCalendar(this.selectedmonth, this.selectedyear);
    }
  }

  selectmonth(){
    this.days = [];
    this.datelist = [];
    this.yearlist = [];
    if ((this.monthlist).length === 0){
      var monthlist = [["January", "February", "March"], ["April", "May", "June"], ["July", "August", "September"], ["October", "November", "December"]];
      this.monthlist = monthlist;
    }
    else{
      this.showCalendar(this.selectedmonth, this.selectedyear);
    }
  }

  pickmonth(monthname){
    if (!this.userdata['editmode']){
      this.selectedmonth = this.monthsArr.indexOf(monthname);
      this.selectedyear = this.selectedyear ? this.selectedyear : this.currentYear;
      this.showCalendar(this.selectedmonth, this.selectedyear);
    }
  }

  pickyear(year) {
    if (!this.userdata['editmode']) {
      this.selectedyear = year;
      this.selectedmonth = this.selectedmonth ? this.selectedmonth : this.currentMonth;
      this.showCalendar(this.selectedmonth, this.selectedyear);
    }
  }

}

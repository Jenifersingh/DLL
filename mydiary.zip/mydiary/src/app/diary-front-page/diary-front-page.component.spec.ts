import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiaryFrontPageComponent } from './diary-front-page.component';

describe('DiaryFrontPageComponent', () => {
  let component: DiaryFrontPageComponent;
  let fixture: ComponentFixture<DiaryFrontPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DiaryFrontPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DiaryFrontPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

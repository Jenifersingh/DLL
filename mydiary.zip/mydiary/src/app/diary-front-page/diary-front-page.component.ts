import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-diary-front-page',
  templateUrl: './diary-front-page.component.html',
  styleUrls: ['./diary-front-page.component.css']
})
export class DiaryFrontPageComponent implements OnInit {

  constructor() { }

  @Input() diaryname;

  ngOnInit(): void {
  }

}

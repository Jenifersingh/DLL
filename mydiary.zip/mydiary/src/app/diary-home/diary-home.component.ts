import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MydiaryapicallService } from '../mydiaryapicall.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-diary-home',
  templateUrl: './diary-home.component.html',
  styleUrls: ['./diary-home.component.css']
})
export class DiaryHomeComponent implements OnInit {

  userid; diary; selectdiary; authToken;
  diaryList = [[]];
  flag = false; displayAdd = true;
  loading = true;
  alert = false;
  alertMessage;
  alertColor;

  constructor(private routes: Router, private route: ActivatedRoute,
     private apicall: MydiaryapicallService, private cookie: CookieService) {
      
  }

  adddiary(){
    if (this.cookie.get("UserId")){
      this.loading = false;
      this.userid = this.cookie.get("UserId")
      this.apicall.addDiary(this.userid).subscribe(
        (diary) => {
          if (diary["Status"] === "True") {
            this.displayAdd = diary["userdiarylist"].length < 4 ? true : false;
            this.formatDiaryList(diary["userdiarylist"]);
            this.alert = true;
            this.alertColor = "alert alert-success alert-dismissible fade show";
            this.alertMessage = diary["Message"];
          }
          else if (diary["Status"] === "False" && diary["Message"].toLowerCase().includes("session expired")){
            this.routes.navigate(["/logout"], {
              relativeTo: this.route
            });
          }
          else{
            this.alert = true;
            this.alertColor = "alert alert-warning alert-dismissible fade show";
            this.alertMessage = diary["Message"];
          }
          this.loading = true;
        },
        (error) => {
          this.loading = true;
          this.alert = true;
          this.alertMessage = "Something went wrong, Please try again!";
          this.alertColor = "alert alert-warning alert-dismissible fade show";
        }
      );
    }

  }

  viewDiary(selectdiary){
    this.selectdiary = selectdiary;
    this.apicall.sharedData = selectdiary;
    this.routes.navigate([`/view-my-diary/`], {
      queryParams: { diaryname: selectdiary.diaryname},
      relativeTo: this.route
    });
  }

  ngOnInit(): void {
    this.alert = false;
    if (this.checkLoggedin()) {
      this.loading = false;
      this.route.queryParams.subscribe(params => {
        this.authToken = params['auth_token'];
      });
      this.userid = this.cookie.get("UserId");
      this.authToken = this.authToken ? this.authToken : this.cookie.get("auth_token");
      this.apicall.getAllUserDiary(this.userid, this.authToken).subscribe(
        (diarylist) => {
          if (diarylist["Status"] === "True"){
            this.displayAdd = diarylist["userdiarylist"].length < 4 ? true : false;
            this.formatDiaryList(diarylist["userdiarylist"]);
            this.routes.navigate(['/my-diary'], {
              relativeTo: this.route
            });
          }
          else if (diarylist["Status"] === "False" && diarylist["Message"].toLowerCase().includes("session expired")) {
            this.routes.navigate(["/logout"], {
              relativeTo: this.route
            });
          }
          else {
            this.alert = true;
            this.alertColor = "alert alert-warning alert-dismissible fade show";
            this.alertMessage = diarylist["Message"];
          }
          this.loading = true; 
        },
        (error) => {
          this.loading = true;
          this.alert = true;
          this.alertMessage = "Something went wrong, Please try again!";
          this.alertColor = "alert alert-warning alert-dismissible fade show";
        }
      );
    }
    else{
      this.cookie.deleteAll();
      this.routes.navigate(['/logout'], {
        relativeTo: this.route
      });
    }
  }

  formatDiaryList(userDiarylist){
    var diary;
    this.diaryList = [[]];
    for (diary of userDiarylist){
      if(this.diaryList[this.diaryList.length - 1].length < 3) {
        this.diaryList[this.diaryList.length - 1].push(diary);
      }
          else {
        this.diaryList.push([diary]);
      }
      if (this.diaryList[this.diaryList.length - 1].length === 3) {
        this.diaryList.push([]);
      }
    } 
  }

  checkLoggedin(){
    var email = this.cookie.get("email");
    var username = this.cookie.get("username");
    var userid = this.cookie.get("UserId");
    if (this.cookie.get("auth_token") && email && username && userid) {
      return true;
    }
    else{
      return false;
    }
  }

}

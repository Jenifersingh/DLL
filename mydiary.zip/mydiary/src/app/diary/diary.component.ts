import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MydiaryapicallService } from '../mydiaryapicall.service';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-diary',
  templateUrl: './diary.component.html',
  styleUrls: ['./diary.component.css']
})
export class DiaryComponent implements OnInit {

  constructor(private routes: Router, private apicall: MydiaryapicallService,
    private route: ActivatedRoute, private cookie: CookieService) {
  }

  @ViewChild('content') content:ElementRef;

  userdiarylist = this.apicall.sharedData;
  message; diaryid; loading = true;
  block = "display: none;";
  alert = false; checkbox = false;
  alertMessage; alertColor; diaryName;
  key: string; urlName;
  tempUserdate; userid; authToken;
  editsave = "fa fa-edit";
  monthsArr = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  today = new Date();
  userdate = { 'date': this.today.getDate(), 'month': this.monthsArr[this.today.getMonth()].substring(0, 3), 'year': this.today.getFullYear(), 'dateselected': this.today.getDate(), 'editmode' : false };
  previousdate = this.userdate;

  ngOnInit(): void {
    if (this.checkLoggedin()){
      if(typeof(this.apicall.sharedData) === "undefined"){
        this.route.queryParams.subscribe(params => {
          this.urlName = params['diaryname'];
        });
        this.loading = false;
        this.userid = this.cookie.get("UserId")
        this.authToken = this.cookie.get("auth_token")
        this.apicall.getAllUserDiary(this.userid, this.authToken).subscribe(
          (response) => {
            this.loading = true;
            if (response["Status"] === "True") {
              var userdiarylist = response["userdiarylist"].filter((content)=>{
                return content.diaryname === this.urlName;
              })[0]
              if (typeof (userdiarylist) !== "undefined"){
                this.message = userdiarylist.diarycontent;
                this.diaryid = userdiarylist.diaryid;
                this.diaryName = userdiarylist.diaryname;
                this.formatDate();
              }
              else {
                this.routes.navigate(['/my-diary'], {
                  relativeTo: this.route
                });
              }
            }
            else{
              this.routes.navigate(['/my-diary'], {
                relativeTo: this.route
              });
            }
          },
          (error) => {
            this.loading = true;
            this.alert = true;
            this.alertMessage = "Something went wrong, Please try again!";
            this.alertColor = "alert alert-warning alert-dismissible fade show";
          }
        );
        
      }
      else{
        this.message = this.userdiarylist.diarycontent;
        this.diaryid = this.userdiarylist.diaryid;
        this.diaryName = this.userdiarylist.diaryname;
        this.formatDate();
      }
    }
    else{
      this.cookie.deleteAll();
      this.routes.navigate(['/logout'], {
        relativeTo: this.route
      });
    }  
  }

  diaryContent;

  changedate(userdate : any){
    if (this.editsave === "fa fa-save"){
      this.block = "display: block; padding-right: 17px; background-color: rgba(0, 0, 0, 0.5);";
      this.tempUserdate = userdate;
      this.userdate['editmode'] = true;
    }
    else{
      this.previousdate = this.userdate;
      userdate['editmode'] = false;
      this.userdate = userdate;
      this.formatDate();
    }

  }



  formatDate(){
    var month; 
    this.monthsArr.map((mon, index)=>{
      if(mon.includes(this.userdate.month)){
        month = index + 1;
        month = month < 10 ? "0" + month : "" + month;
      }
    })
    var date = parseInt(this.userdate.date.toString()) < 10 ? "0" + parseInt(this.userdate.date.toString())  : "" + parseInt(this.userdate.date.toString())
    this.key = date + month + this.userdate.year;
    this.diaryContent = this.message[this.key];
  }



  editSave(){
    if(typeof this.content !== "undefined" && this.editsave === "fa fa-save"){
      this.diaryContent = this.content.nativeElement.innerText;
      if (this.message[this.key] !== this.diaryContent){
        this.message[this.key] = this.diaryContent;
        var userid = this.cookie.get("UserId") ? this.cookie.get("UserId") : "" ;
        var page = {
          pageno: this.key,
          pagecontent: this.diaryContent
        }
        this.loading = false;
        this.apicall.updateDiaryPage(userid, this.diaryid, page).subscribe(
          (response) => {
            console.log(response);
            if (response["Status"] === "True") {
              this.alert = true;
              this.alertColor = "alert alert-success alert-dismissible fade show";
              this.alertMessage = response["Message"];
            }
            else {
              this.alert = true;
              this.alertColor = "alert alert-warning alert-dismissible fade show";
              this.alertMessage = response["Message"];
            }
            this.loading = true;
          },
          (error) => {
            this.loading = true;
            this.alert = true;
            this.alertMessage = "Something went wrong, Please try again!";
            this.alertColor = "alert alert-warning alert-dismissible fade show";
          }
        );
      }
      else{
        this.alert = true;
        this.alertMessage = "No changes to update!";
        this.alertColor = "alert alert-warning alert-dismissible fade show";
      }
    }

    this.editsave = this.editsave == "fa fa-save" ? "fa fa-edit" : "fa fa-save";
    this.userdate['editmode'] = this.editsave == "fa fa-save" ? true : false;
    if (!this.userdate['editmode']){
      this.changedate(this.userdate);
    }
  }

  closeEditModal(){
    this.block = "display: none;"
    this.userdate['editmode'] = this.editsave == "fa fa-save" ? true : false;
  }

  viewNextPage(){
    this.userdate = this.tempUserdate;
    this.formatDate();
    this.closeEditModal();
    this.editsave = "fa fa-edit";
    this.tempUserdate['editmode'] = false;
    this.changedate(this.tempUserdate);
  }

  deleteDiary(){
    this.loading = false;
    var userid = this.cookie.get("UserId") ? this.cookie.get("UserId") : "";
    this.apicall.deleteDiary(userid, this.diaryid).subscribe(
      (response) => {
        if (response["Status"] === "True") {
          this.routes.navigate(['/my-diary'], {
          relativeTo: this.route
          });
        }
        else {
          this.alert = true;
          this.alertColor = "alert alert-warning alert-dismissible fade show";
          this.alertMessage = response["Message"];
        }
        this.loading = true;
      },
      (error) => {
        this.loading = true;
        this.alert = true;
        this.alertMessage = "Something went wrong, Please try again!";
        this.alertColor = "alert alert-warning alert-dismissible fade show";
      }
    );
    
  }

  checkLoggedin() {
    var email = this.cookie.get("email");
    var username = this.cookie.get("username");
    var userid = this.cookie.get("UserId");
    if (this.cookie.get("auth_token") && email && username && userid) {
      return true;
    }
    else {
      return false;
    }
  }

  toogle(checkbox){
    console.log(checkbox)
    this.checkbox = !checkbox;

  }

  updateDiary(){
    if(this.checkbox){
      this.deleteDiary();
    }
    else{  
      var userid = this.cookie.get("UserId") ? this.cookie.get("UserId") : '';
      this.loading = false;
      this.apicall.updateDiary(userid, this.diaryid, this.diaryName).subscribe(
        (response) => {
          if (response["Status"] === "True") {
            this.routes.navigate(['/my-diary'], {
              relativeTo: this.route
            });
          }
          else {
            this.alert = true;
            this.alertColor = "alert alert-warning alert-dismissible fade show";
            this.alertMessage = response["Message"];
          }
          this.loading = true;
        },
        (error) => {
          this.loading = true;
          this.alert = true;
          this.alertMessage = "Something went wrong, Please try again!";
          this.alertColor = "alert alert-warning alert-dismissible fade show";
        }
      );
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../../input';
import { MydiaryapicallService } from '../mydiaryapicall.service';
import { AppComponent } from '../app.component';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  appcomponent; apicall; postlogin = false; userpostList = [];
  private loginData; otp; postId; UserId; useremail; base64textString;
  home = true; profileimage; currentPassword;
  myProfile = false; myProfiletab = "profile";
  signin = false; username = this.cookie.get("username") ? this.cookie.get("username") : "";
  signup = false;
  postus = false;
  changepassword = false;
  forgotpassword = false;
  verifyAccount = false;
  otpbtn = false;
  otpbox = false;
  submitOTP = false;
  class = "fa fa-fw fa-eye field-icon toggle-password";
  type = "password";
  form = "form-control";
  validform = "form-control is-valid";
  invalidform = "form-control is-invalid";
  validtext = "valid-feedback";
  invalidtext = "invalid-feedback";
  formtext = "";
  message = "";
  loading = true;
  alertsuccess = "alert alert-success";
  alertfailure = "alert alert-danger";
  letter = "invalid";
  capital = "invalid";
  number = "invalid";
  length = "invalid";
  loginAlert = "content";
  passwdValscreen = false;
  displayAlert = false;
  userPost = {
    username: "",
    email: "",
    subject: "",
    message: ""
  }
  loginuser: User = {email : "", password : "", repassword : "", username : ""};
  alert = {class : "", message : ""};
  loginvalidation = {
    login: { email: { form: this.form, formtext : this.formtext, message : this.message}, 
      password: { form: this.form, formtext: this.formtext, message: this.message } 
    },
    forgotPassword: {
      email: { form: this.form, formtext: this.formtext, message: this.message },
      otp: { form: this.form, formtext: this.formtext, message: this.message }
    },
    changePassword: {
      password: { form: this.form, formtext: this.formtext, message: this.message },
      repassword: { form: this.form, formtext: this.formtext, message: this.message }
    },
    signup: {
      name: { form: this.form, formtext: this.formtext, message: this.message },
      email: { form: this.form, formtext: this.formtext, message: this.message },
      password: { form: this.form, formtext: this.formtext, message: this.message },
      repassword: { form: this.form, formtext: this.formtext, message: this.message }
    },
  }

  constructor(private routes: Router, private route: ActivatedRoute,
    appcomp: AppComponent, apicall: MydiaryapicallService, private cookie: CookieService) {
    this.apicall = apicall;
    this.appcomponent = appcomp;
    if (this.routes.url === "/login"){
      if (!this.checkLoggedin()){
        this.signinmenu();
      }
      else{
        this.homemenu();      
      }
    }
    else if (this.routes.url === "/register") {
      if (!this.checkLoggedin()) {
        this.signupmenu();
      }
      else {
        this.homemenu();
      }
    }
    else if (this.routes.url === "/myprofile") {
      if (this.checkLoggedin()) {
        this.myprofilemenu();
      }
      else {
        this.homemenu();
      }
    }
    else if (this.routes.url === "/home") {
      this.homemenu();
    }
    else if (this.routes.url === "/forgot-password") {
      this.forgotpwd();
    }
    else if (this.routes.url === "/posts") {
      this.postusmenu();
    }
    else if (this.routes.url.includes("/changepassword")) {
      console.log("inside changepwd")
      this.route.queryParams.subscribe(params => {
        this.otp = params['otp'];
        this.useremail = params['email'];
        this.loginuser.email = params['email'];
        console.log(params)
        if (this.otp && this.loginuser.email){
          this.myProfile = false;
          this.signin = false;
          this.home = false;
          this.signup = false;
          this.forgotpassword = false;
          this.otpbtn = false;
          this.otpbox = false;
          this.submitOTP = false;
          this.changepassword = true;
          this.verifyAccount = false;
          this.postus = false;
        }
        else{
          this.homemenu();
        }
      });
    }
    else if (this.routes.url.includes("/verifyaccount")) {
      console.log("inside verify")
      this.route.queryParams.subscribe(params => {
        this.otp = params['otp'];
        this.useremail = params['email'];
        this.loginuser.email = params['email'];
        console.log(params)
        if (this.otp && this.loginuser.email) {
          this.verifyAccountotp();
        }
        else {
          this.homemenu();
        }
      });      
    }
    else {
      this.homemenu();
    }
  }  
    

  ngOnInit(): void {
    this.checkLoggedin();
    if (this.postlogin){
      this.UserId = this.cookie.get("UserId");
      this.useremail = this.cookie.get("email");
      this.profileimage = localStorage.getItem("profileimage") ? localStorage.getItem("profileimage") : "../assets/undraw_profile.svg";
    }
  }

  login(): void {
    if (this.loginuser.email && this.loginuser.password) {
      if (this.validateEmail(this.loginuser.email) && this.loginuser.password){
        this.loading = false;
        this.apicall.login(this.loginuser).subscribe(
          (data) => {
            this.loginData = JSON.stringify(data);
            this.loading = true;            
            if (this.loading && data.Status === "True"){
              this.cookie.deleteAll();
              this.cookie.set("UserId", data.id);
              this.cookie.set("auth_token", data.auth_token);
              this.cookie.set("email", data.email);
              this.cookie.set("username", data.username);
              this.apicall.userLogin = data;
              this.apicall.authToken = data.auth_token;
              this.routes.navigate(['/login/authorization/'], {
                queryParams: { auth_token: data.auth_token },
                relativeTo: this.route
              });
            }
            else if (this.loading && data.Status === "False" && data.Message.includes("verify the account")){
              this.verifyUserAccount();                    
            }
            else {
              this.alert.class = this.alertfailure;
              this.alert.message = data.Message;
            }
          },
          (error) => {
            this.loading = true;
            this.alert.class = this.alertfailure;
            this.alert.message = "Something went wrong, Please try again!";
          }
        );
      }
    }
    else {
      this.alert.class = this.alertfailure;
      this.alert.message = "Please Enter Credential to continue..";
    }
  }

  register(){
    var flag = true;
    if (!this.loginuser.username) {
      flag = false;
    }
    if (!this.validateEmail(this.loginuser.email)) {
      flag = false;
    }
    if (!this.validatePassword(this.loginuser.password)) {
      flag = false;
    }
    if (!this.validatePassword(this.loginuser.repassword)) {
      flag = false;
    }
    else {
      if (this.loginuser.password !== this.loginuser.repassword) {
        flag = false;
        this.alert.class = this.alertfailure;
        this.alert.message = "Password and Confirm Password not matching!!";
      }
    }

    if(flag){
      this.loading = false;
      this.apicall.register(this.loginuser).subscribe(
        (data) => {
          this.loginData = JSON.stringify(data);
          this.loading = true;
          if (this.loading && data.Status === "True") {
            this.loginAlert = "alert alert-primary";
            this.cookie.set("UserId", data.id);
            this.cookie.set("email", data.email);
            this.cookie.set("username", data.username);
            this.verifyUserAccount();
          }
          else {
            this.alert.class = this.alertfailure;
            this.alert.message = data.Message;
          }
        },
        (error) => {
          this.loading = true;
          this.alert.class = this.alertfailure;
          this.alert.message = "Something went wrong, Please try again!";
        }
      );
    }  
  }


  checkEmpty(event, formevent){
    var inputText, formtype;
    formtype = formevent.split("_");
    inputText = event.target.value;
    this.validatePassword(this.loginuser.password);
      if (inputText){
        if (formtype[1] === "email" && typeof(inputText) !== undefined){
          if (this.validateEmail(inputText)){
            this.loginvalidation[formtype[0]][formtype[1]]['form'] = this.validform;
            this.loginvalidation[formtype[0]][formtype[1]]['formtext'] = this.validtext;
            this.loginvalidation[formtype[0]][formtype[1]]['message'] = "Looks Good!";
          }
          else {
            this.loginvalidation[formtype[0]][formtype[1]]['form'] = this.invalidform;
            this.loginvalidation[formtype[0]][formtype[1]]['formtext'] = this.invalidtext;
            this.loginvalidation[formtype[0]][formtype[1]]['message'] = "Invalid Email Address";
          }
        }
        else {
          this.loginvalidation[formtype[0]][formtype[1]]['form'] = this.validform;
          this.loginvalidation[formtype[0]][formtype[1]]['formtext'] = this.validtext;
          this.loginvalidation[formtype[0]][formtype[1]]['message'] = "Looks Good!";
        }
      }
      else{
        this.loginvalidation[formtype[0]][formtype[1]]['form'] = this.invalidform;
        this.loginvalidation[formtype[0]][formtype[1]]['formtext'] = this.invalidtext;
        this.loginvalidation[formtype[0]][formtype[1]]['message'] = "This field is required";
      }
  }

  validateEmail(email) {
    let pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
    if (pattern.test(email)) {
      return true;
    } else {
      return false;
    }
  }

  displayPwdVal(){
    this.passwdValscreen = true;
  }

  hidePwdVal() {
    this.passwdValscreen = false;
  }

  validatePassword(password) {
    var flag = true;
    var lowerCaseLetters = /[a-z]/g;
    if (password.match(lowerCaseLetters)) {
      this.letter = "valid";
    } else {
      this.letter = "invalid";
      flag = false;
    }

    var upperCaseLetters = /[A-Z]/g;
    if (password.match(upperCaseLetters)) {
      this.capital = "valid";
    } else {
      this.capital = "invalid";
      flag = false;
    }

    var numbers = /[0-9]/g;
    if (password.match(numbers)) {
      this.number = "valid";
    } else {
      this.number = "invalid";
      flag = false;
    }

    if (password.length >= 8) {
      this.length = "valid";
    } else {
      this.length = "invalid";
      flag = false;
    }
    return flag;
  }

  signinmenu(){
    this.routes.navigate(['/login'], {
      relativeTo: this.route
    });
    this.myProfile = false;
    this.signin = true;
    this.home = false;
    this.signup = false;
    this.forgotpassword = false;
    this.otpbtn = false;
    this.otpbox = false;
    this.submitOTP = false;
    this.changepassword = false;
    this.verifyAccount = false;
    this.postus = false;
  }

  signupmenu() {
    this.signin = false;
    this.home = false;
    this.signup = true;
    this.myProfile = false;
    this.forgotpassword = false;
    this.otpbtn = false;
    this.otpbox = false;
    this.submitOTP = false;
    this.changepassword = false;
    this.verifyAccount = false;
    this.postus = false;
    this.routes.navigate(['/register'], {
      relativeTo: this.route
    });
    
  }

  homemenu() {
    this.routes.navigate(['/home'], {
      relativeTo: this.route
    });
    this.myProfile = false;
    this.signin = false;
    this.home = true;
    this.signup = false;
    this.forgotpassword = false;
    this.otpbtn = false;
    this.otpbox = false;
    this.submitOTP = false;
    this.changepassword = false;
    this.verifyAccount = false;
    this.postus = false;
  }

  myprofilemenu(){
    this.routes.navigate(['/myprofile'], {
      relativeTo: this.route
    });
    this.signin = false;
    this.home = false;
    this.signup = false;
    this.myProfile = true;
    this.forgotpassword = false;
    this.otpbtn = false;
    this.otpbox = false;
    this.submitOTP = false;
    this.changepassword = false;
    this.verifyAccount = false;
    this.postus = false;
  }

  myProfileHomeMenu(tabName){
    this.myProfiletab = tabName;
  }

  changePasswordProfile(){
    this.loading = false;
    this.loginuser.email = this.useremail;
    if (this.loginuser.password === this.loginuser.repassword && this.validatePassword(this.loginuser.password)) {
    this.apicall.changeProfilePassword(this.loginuser, this.currentPassword).subscribe(
      (response) => {
        this.loading = true;
        console.log(response)
        if (this.loading && response.Status === "True") {
          this.routes.navigate(['/login'], {
            relativeTo: this.route
          });
        }
        else {
          this.alert.class = this.alertfailure;
          this.alert.message = response.Message;
        }
      },
      (error) => {
        console.log(error)
        this.loading = true;
        this.alert.class = this.alertfailure;
        this.alert.message = "Something went wrong, Please try again!";
      }
    );
    }
    else {
      this.alert.class = this.alertfailure;
      this.alert.message = "Password and confirm password not matching!";
    }
  }

  clickEye = () => {
    this.class = this.class === "fa fa-fw fa-eye field-icon toggle-password" ? "fa fa-fw fa-eye-slash field-icon toggle-password" : "fa fa-fw fa-eye field-icon toggle-password"
    this.type = this.type === "password" ? "text" : "password"
  }
  
  forgotpwd(){
    this.routes.navigate(['/forgot-password'], {
      relativeTo: this.route
    });
    this.signin = false;
    this.home = false;
    this.signup = false;
    this.myProfile = false;
    this.forgotpassword = true;
    this.otpbtn = true;
    this.otpbox = false;
    this.submitOTP = false;
    this.changepassword = false;
    this.verifyAccount = false;
    this.postus = false;
  }

  sendotp(){
    this.loading = false;
    this.apicall.sendotp(this.loginuser).subscribe(
      (response) => {
        this.loading = true;
        if (this.loading && response.Status === "True") {
          this.alert.class = this.alertsuccess;
          this.alert.message = response.Message;
          this.signin = false;
          this.home = false;
          this.signup = false;
          this.myProfile = false;
          this.forgotpassword = true;
          this.otpbtn = false;
          this.otpbox = true;
          this.submitOTP = true;
          this.changepassword = false;
          this.verifyAccount = false;
          this.postus = false;
        }
        else {
          this.alert.class = this.alertfailure;
          this.alert.message = response.Message;
        }
      },
      (error) => {
        this.loading = true;
        this.alert.class = this.alertfailure;
        this.alert.message = "Something went wrong, Please try again!";
      }
    );
  }

  submitotp(){
    this.loading = false;
    this.apicall.verifyUser(this.loginuser, this.otp).subscribe(
      (response) => {
        this.loading = true;
        if (this.loading && response.Status === "True") {
          this.signin = false;
          this.home = false;
          this.signup = false;
          this.myProfile = false;
          this.forgotpassword = false;
          this.otpbtn = false;
          this.otpbox = false;
          this.submitOTP = false;
          this.changepassword = true;
          this.verifyAccount = false;
          this.postus = false;
          this.routes.navigate(['/login'], {
            relativeTo: this.route
          });
        }
        else {
          this.alert.class = this.alertfailure;
          this.alert.message = response.Message;
        }
      },
      (error) => {
        this.loading = true;
        this.alert.class = this.alertfailure;
        this.alert.message = "Something went wrong, Please try again!";
      }
    );
    
  }

  changePassword(){
    if (this.loginuser.password === this.loginuser.repassword && this.validatePassword(this.loginuser.password)){
      this.loading = false;
      this.apicall.changePassword(this.loginuser, this.otp).subscribe(
        (response) => {
          this.loading = true;
          if (this.loading && response.Status === "True") {
            this.signin = false;
            this.home = false;
            this.signup = false;
            this.myProfile = false;
            this.forgotpassword = false;
            this.otpbtn = false;
            this.otpbox = false;
            this.submitOTP = false;
            this.changepassword = false;
            this.verifyAccount = false;
            this.postus = false;
          }
          else {
            this.alert.class = this.alertfailure;
            this.alert.message = response.Message;
          }
        },
        (error) => {
          this.loading = true;
          this.alert.class = this.alertfailure;
          this.alert.message = "Something went wrong, Please try again!";
        }
      );
    }
    else {
      this.alert.class = this.alertfailure;
      this.alert.message = "Password and confirm password not matching!";
    }
  }

  verifyUserAccount(){
    this.signin = false;
    this.home = false;
    this.signup = false;
    this.myProfile = false;
    this.forgotpassword = false;
    this.otpbtn = false;
    this.otpbox = false;
    this.submitOTP = false;
    this.changepassword = false;
    this.verifyAccount = true;
    this.postus = false;
  }

  verifyAccountotp(){
    this.loading = false;
    this.apicall.verifyUser(this.loginuser, this.otp).subscribe(
      (response) => {
        this.loading = true;
        if (this.loading && response.Status === "True") {
          this.alert.class = this.alertsuccess;
          this.alert.message = response.Message;
          this.loginAlert = this.alertsuccess;
          this.routes.navigate(['../login'], {
            relativeTo: this.route
          });
        }
        else {
          this.alert.class = this.alertfailure;
          this.alert.message = response.Message;
        }
      },
      (error) => {
        this.loading = true;
        this.alert.class = this.alertfailure;
        this.alert.message = "Something went wrong, Please try again!";
      }
    );
    
  }

  postComment(){
    var flag = true;
    this.userPost.email = this.cookie.get("email");
    this.userPost.username = this.cookie.get("username");
    var userid = this.cookie.get("UserId");
    
    if (!this.userPost.subject) {
      this.alert.class = this.alertfailure;
      this.alert.message = "Subject is required";
      flag = false;
    }
    if (!this.userPost.message) {
      this.alert.class = this.alertfailure;
      this.alert.message = "Message is required";
      flag = false;
    }

    if(flag){
      this.loading = false;
      this.apicall.userPost(this.userPost, userid).subscribe(
        (response) => {
          this.loading = true;
          if (this.loading && response.Status === "True") {
            this.userPost = {
              username: "",
              email: "",
              subject: "",
              message: ""
            };
            this.userpostList = response.userpostlist.reverse();
            this.alert.class = this.alertsuccess;
            this.alert.message = response.Message;
          }
          else {
            this.alert.class = this.alertfailure;
            this.alert.message = response.Message;
          }
        },
        (error) => {
          this.loading = true;
          this.alert.class = this.alertfailure;
          this.alert.message = "Something went wrong, Please try again!";
        }
      );
    }
  }

  postusmenu(){
    this.routes.navigate(['/posts'], {
      relativeTo: this.route
    });
    var email = this.cookie.get("email");
    var username = this.cookie.get("username");
    var userid = this.cookie.get("UserId");
    if (this.cookie.get("auth_token") && email && username && userid){
      this.postlogin = true;
    }
    this.loading = false;
    this.apicall.getallPost().subscribe(
      (response) => {
        this.loading = true;
        if (this.loading && response.Status === "True") {
          this.userpostList = response.userpostlist.reverse();
        }
      },
      (error) => {
        this.loading = true;
        this.alert.class = this.alertfailure;
        this.alert.message = "Something went wrong, Please try again!";
      }
    );
    this.signin = false;
    this.home = false;
    this.signup = false;
    this.myProfile = false;
    this.forgotpassword = false;
    this.otpbtn = false;
    this.otpbox = false;
    this.submitOTP = false;
    this.changepassword = false;
    this.verifyAccount = false;
    this.postus = true;

  }

  checkLoggedin(){
    var email = this.cookie.get("email");
    var username = this.cookie.get("username");
    var userid = this.cookie.get("UserId");
    if (this.cookie.get("auth_token") && email && username && userid) {
      this.postlogin = true;
      return true;
    }
    else{
      return false;
    }
  }

  goToMyDiary(){
    this.routes.navigate(['/my-diary'], {
         relativeTo: this.route
       });
  }

  setPostId(postid){
    this.postId = postid;
  }

  deletePost(){
    var userid = this.cookie.get("UserId");
    this.loading = false;
    this.apicall.deletePost(userid, this.postId).subscribe(
      (response) => {
        this.loading = true;
        if (this.loading && response.Status === "True") {
          this.userpostList = response.userpostlist.reverse();
        }
      },
      (error) => {
        this.loading = true;
        this.alert.class = this.alertfailure;
        this.alert.message = "Something went wrong, Please try again!";
      }
    );
  }

  updateProfile(image){
    const file = image.files[0];

    if (file) {
      const reader = new FileReader();
      reader.onload = this.handleReaderLoaded.bind(this);
      reader.readAsBinaryString(file);
      console.log(this.base64textString)
      
    }
    
  }

  handleReaderLoaded(e) {
    this.base64textString = 'data:image/png;base64,' + btoa(e.target.result);
    this.loading = false;
    this.apicall.uploadimage(this.UserId, this.base64textString).subscribe(
      (response) => {
        this.loading = true;
        if (this.loading && response.Status === "True") {
          this.base64textString = response.profileimage;
          localStorage.setItem("profileimage", response.profileimage);
        }
      },
      (error) => {
        this.loading = true;
        this.alert.class = this.alertfailure;
        this.alert.message = "Something went wrong, Please try again!";
      }
    );
  }
}

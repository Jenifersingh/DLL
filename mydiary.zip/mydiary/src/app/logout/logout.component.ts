import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private routes: Router, private route: ActivatedRoute,
    private cookie: CookieService) {
    this.cookie.deleteAll();
  }

  ngOnInit(): void {
    this.cookie.deleteAll();
  }

  login(){
    this.routes.navigate(['/login'], {
      relativeTo: this.route
    });
  }

  home() {
    this.routes.navigate(['/home'], {
      relativeTo: this.route
    });
  }

}

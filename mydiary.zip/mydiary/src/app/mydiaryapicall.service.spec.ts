import { TestBed } from '@angular/core/testing';

import { MydiaryapicallService } from './mydiaryapicall.service';

describe('MydiaryapicallService', () => {
  let service: MydiaryapicallService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MydiaryapicallService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

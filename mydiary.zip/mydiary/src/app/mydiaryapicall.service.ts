import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../input';
import { Observable } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})

export class MydiaryapicallService{

  sharedData;
  userLogin; authToken = "";
  apiUrl = "https://mydiary-india.herokuapp.com";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: this.cookie.get("auth_token") ? this.cookie.get("auth_token") : this.authToken
    })
  };

  constructor(private http: HttpClient, private cookie: CookieService) { 

  }

  login(user): Observable<User>{
    var url = this.apiUrl + "/api/v1/mydiary/login";
    var body = { "email": user.email, "password": user.password};
    return this.http.post<User>(url, body, this.httpOptions);
  }

  register(user): Observable<User> {
    var url = this.apiUrl + "/api/v1/mydiary/signup";
    var body = { "email": user.email, "password": user.password };
    return this.http.post<User>(url, user, this.httpOptions);
  }

  sendotp(user): Observable<User> {
    var url = this.apiUrl + "/api/v1/mydiary/sendotp";
    var body = { "email": user.email};
    return this.http.put<User>(url, user, this.httpOptions);
  }

  verifyUser(user, otp) {
    var url = this.apiUrl + `/api/v1/mydiary/${user.email}/verifyuser`;
    var body = {"otp": otp};
    return this.http.put(url, body, this.httpOptions);
  }

  changePassword(user, otp) {
    var url = this.apiUrl + `/api/v1/mydiary/changepassword`;
    var body = { "otp": otp , "email": user.email, "password": user.password, "repassword": user.repassword };
    return this.http.put(url, body, this.httpOptions);
  }

  changeProfilePassword(user, currentpassword) {
    var url = this.apiUrl + `/api/v1/mydiary/profilechangepassword`;
    var body = { "currentpassword": currentpassword, "email": user.email, "password": user.password, "repassword": user.repassword };
    return this.http.put(url, body, this.httpOptions);
  }

  uploadimage(userid, image) {
    var url = this.apiUrl + `/api/v1/mydiary/${userid}/uploadimage`;
    var body = { "profileimage": image};
    return this.http.put(url, body, this.httpOptions);
  }

  addDiary(userid) {
    var url = this.apiUrl + `/api/v1/mydiary/${userid}/adddiary`;
    var body = { };
    return this.http.post(url, body, this.httpOptions);
  }

  getAllUserDiary(userid, authToken){
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: authToken
      })
    };
    var url = this.apiUrl + `/api/v1/mydiary/${userid}/getalldiary`;
    return this.http.get(url, this.httpOptions);
  }

  updateDiary(userid, diaryid, diaryname) {
    var url = this.apiUrl + `/api/v1/mydiary/${userid}/updatemydiary/${diaryid}`;
    return this.http.put(url, { diaryname: diaryname}, this.httpOptions);
  }

  updateDiaryPage(userid, diaryid, diarycontent) {
    var url = this.apiUrl + `/api/v1/mydiary/${userid}/updatepage/${diaryid}`;
    return this.http.put(url, diarycontent, this.httpOptions);
  }

  deleteDiary(userid, diaryid) {
    var url = this.apiUrl + `/api/v1/mydiary/${userid}/deletediary/${diaryid}`;
    return this.http.delete(url, this.httpOptions);
  }

  userPost(post, userid) {
    var url = this.apiUrl + `/api/v1/mydiary/${userid}/post`;    
    return this.http.post(url, post, this.httpOptions);
  }

  getallPost() {
    var url = this.apiUrl + "/api/v1/mydiary/getallpost";
    return this.http.get(url);
  }

  deletePost(userid, postid) {
    var url = this.apiUrl + `/api/v1/mydiary/${userid}/deletepost/${postid}`;
    return this.http.delete(url, this.httpOptions);
  }

  logout(userid) {
    var url = this.apiUrl + `/api/v1/mydiary/logout`;
    userid = { id: userid};
    return this.http.put(url, userid, this.httpOptions);
  }

  
}

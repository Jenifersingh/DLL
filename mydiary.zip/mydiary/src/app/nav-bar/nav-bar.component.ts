import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { MydiaryapicallService } from '../mydiaryapicall.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  username; profileimage; loading = true;
  constructor(private routes: Router, private route: ActivatedRoute,
    private apicall: MydiaryapicallService, private cookie: CookieService) {

  }

  ngOnInit(): void {
    this.username = this.cookie.get("username") ? this.cookie.get("username").toUpperCase() : "";
    this.profileimage = localStorage.getItem("profileimage") ? localStorage.getItem("profileimage") : "../assets/undraw_profile.svg";
  }

  logout(){
    var userid = this.cookie.get("UserId");
    this.loading = false;
    this.apicall.logout(userid).subscribe(
      (response) => {
        this.loading = true;
        if (this.loading && response["Status"] === "True") {
          this.cookie.deleteAll();
          this.routes.navigate(['/logout'], {
            relativeTo: this.route
          });
        }
        else{
          this.cookie.deleteAll();
          this.routes.navigate(['/logout'], {
            relativeTo: this.route
          });
        }
      },
      (error) => {
        this.loading = true;
        this.cookie.deleteAll();
        this.routes.navigate(['/logout'], {
          relativeTo: this.route
        });
      }
    );
    
  }

  home(){
    this.routes.navigate(['/home'], {
      relativeTo: this.route
    });
  }

  posts() {
    this.routes.navigate(['/posts'], {
      relativeTo: this.route
    });
  }

  myprofile() {
    this.routes.navigate(['/myprofile'], {
      relativeTo: this.route
    });
  }

}
